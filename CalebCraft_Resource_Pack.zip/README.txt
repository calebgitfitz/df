CalebCraft SMP Resource Pack

Special logo character:


Use it in TAB config like:
title: ""
or:
- ""
- "&b&lCALEBCRAFT SMP"

Put CalebCraft_Resource_Pack.zip somewhere direct-downloadable and add it to server.properties:
resource-pack=<DIRECT ZIP URL>
require-resource-pack=true

Then restart the server.
